alert("Welcome to your bank's website!")
var deposit = prompt("How much would you like to deposit today?")
alert("You've deposited: "+deposit+" into your account.")
console.log("You are a cool person!")
