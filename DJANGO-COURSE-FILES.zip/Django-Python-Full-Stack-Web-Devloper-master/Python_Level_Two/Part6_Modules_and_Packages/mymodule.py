# This is the module we will be importing from!
# Great resource: https://docs.python.org/3/tutorial/modules.html

def func_in_mymodule():
    print("I am a function inside of the mymodule.py file!")
